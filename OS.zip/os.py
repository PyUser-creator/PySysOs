import time

print("version 0.1")
time.sleep(0.4)
print("starting")
time.sleep(0.4)
print("hello")
bkzguk = input("# ")
if bkzguk == version:
  print(0.1)